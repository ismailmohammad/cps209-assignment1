Mohammad Ismail
500777447 m11ismail
CPS209 Assignment 1.
Java Files Submitted: Vehicle.java, Car.java, CarDealership.java, CarDealershipSimulator.java

Can be compiled/run without issues.

All requirements are tested/expected to be working:
- Basic Commands: L, Q, ADD, BUY, RET; Classes Car, CarDealership, CarDealershipSimulator
- Creation of x Car objects from cars.txt; ADD command
- All sort commands (Price (Ascending), Safety Rating (Descending), Max Range(Descending))
- All filter commands (price (min, max), AWD, Electric, clear filters)
- File I/O: Attempts to load cars.txt file. Please feel free to use own cars.txt
Parses/Validates whether each input line is indeed a valid Car. If file isn't found
then it fallsback to using DEMO_CARS based on provided file with 1 added invalid Car as an
example.
- Exceptions: Implemented exception throws in buyCar(), returnCar(), and filterByPrice()
in class CarDealership. Exceptions handled in CarDealershipSimulator along with other
exceptions such as when parsing cars.txt or DEMO_CARS.
